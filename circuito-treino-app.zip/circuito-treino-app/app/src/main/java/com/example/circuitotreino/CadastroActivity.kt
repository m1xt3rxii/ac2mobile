package com.example.circuitotreino

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class CadastroActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro)

        val nomeInput = findViewById<EditText>(R.id.edit_nome)
        val duracaoInput = findViewById<EditText>(R.id.edit_duracao)
        val btnSalvar = findViewById<Button>(R.id.btn_salvar)

        btnSalvar.setOnClickListener {
            val nome = nomeInput.text.toString()
            val duracao = duracaoInput.text.toString().toIntOrNull() ?: 0
            if (nome.isNotBlank() && duracao > 0) {
                MainActivity.exercicios.add(Exercicio(nome, duracao))
                finish()
            }
        }
    }
}