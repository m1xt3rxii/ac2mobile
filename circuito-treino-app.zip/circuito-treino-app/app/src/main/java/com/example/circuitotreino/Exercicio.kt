package com.example.circuitotreino

data class Exercicio(val nome: String, val duracaoSegundos: Int)