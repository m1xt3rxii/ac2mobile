package com.example.circuitotreino

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.ListView

class MainActivity : AppCompatActivity() {
    companion object {
        val exercicios = mutableListOf<Exercicio>()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val listView: ListView = findViewById(R.id.lista_exercicios)
        val btnAdd: Button = findViewById(R.id.btn_add_exercicio)
        val btnIniciar: Button = findViewById(R.id.btn_iniciar_treino)

        val adapter = ExercicioAdapter(this, exercicios)
        listView.adapter = adapter

        btnAdd.setOnClickListener {
            startActivity(Intent(this, CadastroActivity::class.java))
        }

        btnIniciar.setOnClickListener {
            val intent = Intent(this, TreinoService::class.java)
            startForegroundService(intent)
        }
    }
}