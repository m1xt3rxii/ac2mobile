package com.example.circuitotreino

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder

class TreinoService : Service() {
    private val canalId = "treino_channel"
    private lateinit var notificationManager: NotificationManager
    private var indiceAtual = 0

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        criarCanalNotificacao()
        iniciarTreino()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun criarCanalNotificacao() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canal = NotificationChannel(canalId, "Canal do Treino", NotificationManager.IMPORTANCE_HIGH)
            notificationManager.createNotificationChannel(canal)
        }
    }

    private fun iniciarTreino() {
        if (indiceAtual >= MainActivity.exercicios.size) {
            pararComMensagem("Treino concluído! Parabéns!")
            return
        }

        val atual = MainActivity.exercicios[indiceAtual]
        val notification = Notification.Builder(this, canalId)
            .setContentTitle("Exercício Atual")
            .setContentText(atual.nome)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()

        startForeground(1, notification)

        object : CountDownTimer((atual.duracaoSegundos * 1000).toLong(), 1000) {
            override fun onTick(millisUntilFinished: Long) {}
            override fun onFinish() {
                indiceAtual++
                iniciarTreino()
            }
        }.start()
    }

    private fun pararComMensagem(msg: String) {
        val notification = Notification.Builder(this, canalId)
            .setContentTitle("Fim do treino")
            .setContentText(msg)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        notificationManager.notify(2, notification)
        stopSelf()
    }
}