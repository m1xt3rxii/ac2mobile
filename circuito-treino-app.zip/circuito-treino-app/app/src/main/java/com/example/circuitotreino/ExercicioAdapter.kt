package com.example.circuitotreino

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class ExercicioAdapter(context: Context, items: List<Exercicio>) :
    ArrayAdapter<Exercicio>(context, 0, items) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_exercicio, parent, false)
        val exercicio = getItem(position)
        view.findViewById<TextView>(R.id.text_nome).text = exercicio?.nome
        view.findViewById<TextView>(R.id.text_duracao).text = "${exercicio?.duracaoSegundos}s"
        return view
    }
}